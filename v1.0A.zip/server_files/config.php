<?php
    $CONFIG["dbname_urlredirect"] = "urlredirect";
    $CONFIG["dbname_accounts"] = "accounts";
    $CONFIG["dbname_global_chat"] = "forum";
    $CONFIG["dbname_kitchen"] = "kitchen";
    $CONFIG["db_user"] = "root";
    $CONFIG["db_pass"] = "thomas";
    $CONFIG["db_host"] = "localhost";
    $CONFIG["cookie_time_minutes"] = "10";
?>
