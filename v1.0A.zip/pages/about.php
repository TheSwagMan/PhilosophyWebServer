<p>This project is an interactive learning interface where accounts can be used to chat with other in the global chat. You can also access a global cloud where privileged members can drop files.</p>
<p>Created, designed and coded by Thomas POTIER &lt;theswagman@gmx.fr&gt;</p>
