<?php
    //Disconnect page
    clearSession($cookie_session_hash);
    header("Location: /");
?>